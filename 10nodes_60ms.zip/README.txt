The variable CIJ_w contains a matrix with 7x10x56183 elements.
7x10 is the respectively the number of transmitters and receivers. The 7 on-body nodes in my applications both transmit and receives in round robin manner, instead the off-body nodes only listens.
56183 is the number of time instant which were measured. The resolution is 60ms. At each instant you have a characterization of the BAN propation at that instant in the BAN mesh network. 

Positions of the nodes:
    left ankle~(1)
    right arm~(2)
    left wrist~(3)
    waist~(4)
    right ankle~(5)
    low centred back~(6)
    high centred back~(7). 

    (8) (9) (10) are off-body close to the wall of the room.

    
